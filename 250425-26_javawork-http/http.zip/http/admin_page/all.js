  const favicon = document.createElement("link");
  favicon.rel = "icon";
  favicon.href = "/images/administrator.png";
  favicon.type = "image/png";
  document.head.appendChild(favicon);