package com.kiosk.order.model;

import lombok.Data;

@Data
public class OrdersDTO {
	private int quantity;
}
