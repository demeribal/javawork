package com.kiosk.office.DTO;

import lombok.Data;


@Data
public class OfficeDTO {
    private int id;
    private int userId;
    private String officeName;
}