package user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import order.model.Order;
import order.service.OrderService;
import user.model.User;
import user.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService; 
	

	// 세션에서 user 정보 가져옴
	private User getUserFromSession(HttpServletRequest request) {
	    HttpSession session = request.getSession();
	    String userId = (String) session.getAttribute("user");
	    if (userId == null) {
			userId = "user1";  // 기본 사용자 ID로 "user1"을 설정
			session.setAttribute("user", userId);  // 세션에 user1 저장
		}

		return userService.findUserById(userId);
	}


	@GetMapping("/mypage")
	public String mypage(Model model, HttpServletRequest request) {
	    User user = getUserFromSession(request); 
	    model.addAttribute("user", user);
	    return "mypage";
	}

	@GetMapping("/edit")
	public String editUser(Model model, HttpServletRequest request) {
	    User user = getUserFromSession(request);
	    model.addAttribute("user", user);
	    return "/user/userEditForm";  
	}
	
	/*
 	@GetMapping("/mypage")
    public String mypage(Model model,HttpServletRequest request) {
    	HttpSession session=request.getSession();
    	session.setAttribute("user","user1");	//다른곳에서 세션 저장하면 이 줄은 삭제
    	//User user = userService.findUserById("user1");
    	User user = userService.findUserById((String)session.getAttribute("user"));
        model.addAttribute("user", user);
        return "mypage";
    }
    
    @GetMapping("/edit")
    public String editUser(Model model,HttpServletRequest request) {
    	HttpSession session=request.getSession();
    	session.setAttribute("user","user1");	//다른곳에서 세션 저장하면 이 줄은 삭제
    	//User user = userService.findUserById("user1");
    	User user = userService.findUserById((String)session.getAttribute("user"));
        model.addAttribute("user", user);
        return "/user/userEditForm";  
    }
	 */

    
	@PostMapping("/userEditSuccess")
	public String updateUser(@ModelAttribute User user, HttpServletRequest request, Model model) {

		User userSession = getUserFromSession(request);

		userSession.setNickname(user.getNickname());
		userSession.setAddress(user.getAddress());
		userSession.setPhone(user.getPhone());
		userSession.setEmail(user.getEmail()); 
		
		userService.updateUser(userSession);
	
		model.addAttribute("user", userSession);
		return "redirect:/user/mypage";
	}

	@GetMapping("/editPassword")
	public String changePasswordForm(Model model, HttpServletRequest request) {
	    User user = getUserFromSession(request);
	    model.addAttribute("user", user);
	    return "/user/editPassword";
	}
	
	@PostMapping("/editPassword")
	public String changePassword(@RequestParam("currentPassword") String currentPassword,
	                             @RequestParam("newPassword") String newPassword,
	                             @RequestParam("confirmPassword") String confirmPassword,
	                             HttpServletRequest request, Model model) {

		User user = getUserFromSession(request);


	    if (!userService.checkPassword(user, currentPassword)) {
	        model.addAttribute("currentPasswordError", "현재 비밀번호가 올바르지 않습니다.");
	        return "user/editPassword"; 
	    }

	    // 새 비밀번호와 확인 비밀번호가 일치하는지 확인
	    if (!newPassword.equals(confirmPassword)) {
	        model.addAttribute("passwordMismatchError", "새 비밀번호와 비밀번호 확인이 일치하지 않습니다.");
	        return "user/editPassword";
	    }

	    // 비밀번호 변경
	    user.setPassword(newPassword);
	    userService.updateUser(user); // 사용자 정보 업데이트

	    model.addAttribute("user", user);
	    return "redirect:/user/mypage"; // 변경 후 마이페이지로 리다이렉트
	
	}


   
}
