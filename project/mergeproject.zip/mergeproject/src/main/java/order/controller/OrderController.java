package order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import order.model.Order;
import order.service.OrderService;

@Controller
@RequestMapping("/order")
public class OrderController {
	
    @Autowired
    private OrderService orderService;
	
    @GetMapping("/orderList")
    public String orderList(@RequestParam(defaultValue = "1") int page, Model model) {
        int size = 5; 
        List<Order> orderList = orderService.findAllOrdersPaging(page, size);
        
 
        int totalOrders = orderService.countOrders();
        int totalPages = (int) Math.ceil((double) totalOrders / size); 


        model.addAttribute("orderList", orderList);
        model.addAttribute("currentPage", page); 
        model.addAttribute("totalPages", totalPages); 
        
        return "/order/viewOrderList";
    }
    
    @GetMapping("/shippingInfo")
    public String shippingInfo(Model model) {
        
        return "/order/shippingInfo";
    }
    
	@GetMapping("/contact")
	public String contact(@RequestParam("order_id") Integer order_id, Model model) {
		Order order = orderService.findOrderById(order_id);
		model.addAttribute("order", order);
	    return "/order/contact";
	}
	
	
	 @PostMapping("/contact")
    public String submitInquiry(@RequestParam("order_id") Integer order_id, @RequestParam("message") String message) {
        orderService.submitContact(order_id, message);
        return "redirect:/order/orderList";
    }
}
