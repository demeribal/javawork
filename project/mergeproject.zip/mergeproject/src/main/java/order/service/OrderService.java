package order.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import order.model.Order;
import order.repository.OrderMapper;

@Service
public class OrderService {
	
	@Autowired
    private OrderMapper orderMapper;

    // 모든 주문 내역을 반환하는 메서드
    public List<Order> findAllOrdersPaging(int page, int size) {
    	int offset = (page - 1) * size; // 0-based index
	    return orderMapper.findAllOrdersPaging(offset, size);
    }

	public int countOrders() {
		Integer count = orderMapper.countOrders(); 
	    return (count != null) ? count : 0;
	}

	public Order findOrderById(Integer order_id) {
		 return orderMapper.findOrderById(order_id);
	}

	public void submitContact(Integer order_id, String message) {
	    // orderId를 String으로 변환해서 findOrderById 호출
		Order order = orderMapper.findOrderById(order_id);
	    
	    if (order != null) {
	        // 문의 내용을 order 객체에 설정
	        order.setMessage(message);  // 문의 내용
	        order.setContact_date(new Date());  // 문의 날짜 (현재 날짜)

	        // order_contact 테이블에 데이터 삽입
	        orderMapper.insertOrderContact(order);
	    }
	}

}
