package order.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import order.model.Order;

@Mapper
public interface OrderMapper {

	List<Order> findAllOrdersPaging(@Param("offset") int offset, @Param("limit") int limit);


	Integer countOrders();


	Order findOrderById(Integer order_id);


	void insertOrderContact(Order order);

}
